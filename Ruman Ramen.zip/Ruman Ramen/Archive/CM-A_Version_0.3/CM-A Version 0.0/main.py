import pygame

pygame.init()

from config import Config
from render import fill_tile_map

config = Config()

running = True


def main():
    global running

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                break

        config.screen.fill("blue")

        # draw_textures(config.screen)
        fill_tile_map()

        pygame.display.update()

        config.clock.tick(config.FPS)

    pygame.quit()


main()
