#
import pygame
import os, random, sys

#todo: 
#todo: 
#todo: 

                    #? SETUP

pygame.init()

pygame.display.set_caption('game')
clock = pygame.time.Clock()

global SCREENWIDTH, SCREENHEIGHT
SCREENWIDTH, SCREENHEIGHT = 1500, 900

class Board:
    
    def __init__(self):        
        self.tile_size = 20
        self.row = SCREENHEIGHT // self.tile_size
        self.col = SCREENWIDTH // self.tile_size

    def construct_board(self, screen):
        for row in range(self.row):
            for col in range(self.col):
                x = col * self.tile_size
                y = row * self.tile_size

            #     # Draw the tile
            #     pygame.draw.rect(screen, "blue", [x, y, self.tile_size, self.tile_size])

            #     # Draw grid lines
            #     pygame.draw.line(screen, "white", [x, y], [x + self.tile_size, y])  # Horizontal line
            #     pygame.draw.line(screen, "white", [x, y], [x, y + self.tile_size])  # Vertical line

            # # Draw the bottom grid line of the last row
            # pygame.draw.line(screen, "white", [SCREENHEIGHT - 1], [SCREENWIDTH, SCREENHEIGHT - 1])

                    

board = Board()
screen = pygame.display.set_mode((SCREENWIDTH, SCREENHEIGHT))


                    #? VARIABLES 
FPS = 60
run = True

RED, GREEN, BLUE = (255, 0, 0), (0, 255, 0), (0, 0, 255)
BLACK, WHITE = (0, 0, 0), (255, 255, 255)



                    #? LISTS AND FILES




                    #? CLASSES

#* SUPER CLASS for player     
class Player(pygame.sprite.Sprite):
    def __init__(self, width, height, x_pos, y_pos):
        super().__init__()

        #code for player here





#* SUPER CLASS for enemy
class Enemy(pygame.sprite.Sprite):
    def __init__(self, width, height, x_pos, y_pos):
        super().__init__()

        #add code for an enemy here


        


#* SUB CLASS for mushroom enemy
class Mushroom(Enemy):
    def __init__(self, width, height, x_pos, y_pos):
        super().__init__(width, height, x_pos, y_pos)

        #add mushrooom characterisitcs here



                    #? OBJECTS



                    #? TEXTURES
#grass floor texture
grass_floor_texture = pygame.image.load(os.path.join('Assets', 'Textures', 'Surfaces', 'Grass.png'))
grass_floor_rect = grass_floor_texture.get_rect()
grass_floor_rect.bottomleft = (0, SCREENHEIGHT)

#main sky
main_sky_texture = pygame.image.load(os.path.join('Assets', 'Textures', 'Surfaces', 'Sky_1.png'))
main_sky_rect = main_sky_texture.get_rect()
main_sky_rect.topleft = (0, 0)

                    #? FUNCTIONS

def BlitSurface(surface, pos):
    screen.blit(surface, pos)


def moveSky():
    main_sky_rect.bottomleft[0] += 1


                    #? MAIN FUNCTIONS

def main():
    i=0
    while True:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill(BLACK)


        #board.construct_board(screen)

        BlitSurface(surface=main_sky_texture, pos = (main_sky_rect[0]-(i/10), main_sky_rect[1]))
        BlitSurface(surface=grass_floor_texture, pos = grass_floor_rect)
        i += 1
        
        print(i)
        if i >= 400:
            i=0

        #moveSky()
        


        pygame.display.update()
        clock.tick(FPS)

################################################################################################
main()
