#simple animations

from CMGO_Version_0_1 import screen, cloud_1_texture, cloud_2_texture, cloud_1_velocity, cloud_2_velocity, cloud_3_velocity

def moveClouds():
    global screen, cloud_1_texture, cloud_2_texture, cloud_3_texture
    global cloud_1_xpos, cloud_1_ypos, cloud_2_xpos, cloud_2_ypos, cloud_3_xpos, cloud_3_ypos

    #cloud1
    screen.blit(cloud_1_texture, (cloud_1_xpos, cloud_1_ypos))
    cloud_1_xpos += cloud_1_velocity
    if cloud_1_xpos >= 1500:
        cloud_1_xpos = -1000

    #cloud2
    screen.blit(cloud_2_texture, (cloud_2_xpos, cloud_2_ypos))
    cloud_2_xpos += cloud_2_velocity
    if cloud_2_xpos >= 1500:
        cloud_2_xpos = -1000

    #cloud3
    screen.blit(cloud_3_texture, (cloud_3_xpos, cloud_3_ypos))
    cloud_3_xpos += cloud_3_velocity
    if cloud_3_xpos >= 1500:
        cloud_3_xpos = -450
