print('hello world')

import pygame

pygame.init()

import os, random, sys

                    #? SETUP

SCREENWIDTH, SCREENHEIGHT = 1500, 900

WIN = pygame.display.set_mode((SCREENWIDTH, SCREENHEIGHT))
pygame.display.set_caption('game')

FPS = 60

clock = pygame.time.Clock()


                    #? VARIABLES 

run = True

RED, GREEN, BLUE = (255, 0, 0), (0, 255, 0), (0, 0, 255)
BLACK, WHITE = (0, 0, 0), (255, 255, 255)



                    #? LISTS AND FILES



                    #? FUNCTIONS





                    #? MAIN FUNCTIONS


def main():
    while True: 
        

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()


        WIN.fill(BLACK)
        pygame.display.update()



################################################################

main()
