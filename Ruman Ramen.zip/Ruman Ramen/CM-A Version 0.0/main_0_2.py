#
import pygame
import os, random, sys
import csv, ast

#
from SIMPLE_ANIMATIONS_VERSION_0_1 import moveClouds

#todo: 
#todo: 
#todo: 
6
                    #? SETUP

pygame.init()

pygame.display.set_caption('ur mom')
clock = pygame.time.Clock()

global SCREENWIDTH, SCREENHEIGHT
SCREENWIDTH, SCREENHEIGHT = 1500, 900

class Config:
    
    def __init__(self):
        self.SCREENWIDTH = 1500
        self.SCREENHEIGHT = 900

        self.tile_size = 60
        self.row = self.SCREENHEIGHT // self.tile_size
        self.col = self.SCREENWIDTH // self.tile_size

        pygame.display.set_caption('CMGO-Version 0.0')

        # setup window
        self.clock = pygame.time.Clock()
        self.FPS = 300

config = Config()

# main sky texture transformed
main_sky_texture = pygame.image.load('Assets/Textures/Surfaces/Sky_1_B.png')
main_sky_texture = pygame.transform.scale(main_sky_texture, (config.tile_size, config.tile_size))

# dirt floor texture transformed
dirt_floor_texture = pygame.image.load('Assets/Textures/Surfaces/Dirt_B.png')
dirt_floor_texture = pygame.transform.scale(dirt_floor_texture, (config.tile_size, config.tile_size))

# grass floor texture transformed
grass_floor_texture = pygame.image.load('Assets/Textures/Surfaces/Grass_B.png')
grass_floor_texture = pygame.transform.scale(grass_floor_texture, (config.tile_size, config.tile_size))


screen = pygame.display.set_mode((SCREENWIDTH, SCREENHEIGHT))


                    #? VARIABLES 
FPS = 60
run = True

RED, GREEN, BLUE = (255, 0, 0), (0, 255, 0), (0, 0, 255)
BLACK, WHITE = (0, 0, 0), (255, 255, 255)



                    #? LISTS AND FILES




                    #? CLASSES

#* SUPER CLASS for player     
class Player(pygame.sprite.Sprite):
    def __init__(self, width, height, x_pos, y_pos):
        super().__init__()

        #code for player here





#* SUPER CLASS for enemy
class Enemy(pygame.sprite.Sprite):
    def __init__(self, width, height, x_pos, y_pos):
        super().__init__()

        #add code for an enemy here


        


#* SUB CLASS for mushroom enemy
class Mushroom(Enemy):
    def __init__(self, width, height, x_pos, y_pos):
        super().__init__(width, height, x_pos, y_pos)

        #add mushrooom characterisitcs here



                    #? OBJECTS



                    #? TEXTURES
#grass floor texture
grass_floor_texture = pygame.image.load(os.path.join('Assets', 'Textures', 'Surfaces', 'Grass_A.png'))
grass_floor_rect = grass_floor_texture.get_rect()
grass_floor_rect.bottomleft = (0, SCREENHEIGHT)

#main sky
main_sky_texture = pygame.image.load(os.path.join('Assets', 'Textures', 'Surfaces', 'Sky_1_C.png'))
main_sky_rect = main_sky_texture.get_rect()
main_sky_rect.topleft = (0, 0)



cloud_1_height, cloud_2_height, cloud_3_height = 60, 60, -25
cloud_1_velocity, cloud_2_velocity, cloud_3_velocity = 0.2, 0.5, 0.35

#cloud 1
cloud_1_texture = pygame.image.load(os.path.join('Assets', 'Textures', 'clouds', 'Cloud_1_H.png'))
cloud_1_rect = cloud_1_texture.get_rect()
cloud_1_rect.topleft = (0, cloud_1_height)
cloud_1_xpos, cloud_1_ypos = cloud_1_rect.topleft[0], cloud_1_rect.topleft[1]
cloud_1_pos = (cloud_1_xpos, cloud_1_ypos)

#cloud 2
cloud_2_texture = pygame.image.load(os.path.join('Assets', 'Textures', 'Clouds', 'Cloud_2_B.png'))
cloud_2_rect = cloud_2_texture.get_rect()
cloud_2_rect.topleft = (750, cloud_2_height)
cloud_2_xpos, cloud_2_ypos = cloud_2_rect.topleft[0], cloud_2_rect.topleft[1]
cloud_2_pos = (cloud_2_xpos, cloud_2_ypos)

#cloud 3
cloud_3_texture = pygame.image.load(os.path.join('Assets', 'Textures', 'Clouds', 'Cloud_3_A.png'))
cloud_3_rect = cloud_3_texture.get_rect()
cloud_3_rect.topleft = (-400, cloud_3_height)
cloud_3_xpos, cloud_3_ypos = cloud_3_rect.topleft[0], cloud_3_rect.topleft[1]
cloud_3_pos = (cloud_3_xpos, cloud_3_ypos)



                    #? FUNCTIONS

def BlitSurface(surface, pos):
    screen.blit(surface, pos)



                    #? MAIN FUNCTIONS

def main():
    
    while True:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill(BLACK)


        #board.construct_board(screen)

        BlitSurface(surface=main_sky_texture, pos = main_sky_rect)
        BlitSurface(surface=grass_floor_texture, pos = grass_floor_rect)
        

        moveClouds()
        

        pygame.display.update()
        clock.tick(FPS)

################################################################################################
main()


